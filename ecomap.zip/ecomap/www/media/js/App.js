var app = angular.module('app', ['ngAnimate', 'ngCookies', 'ngMessages',
                                'ui.router', 'ui.bootstrap', 'satellizer',
                                'toaster', 'textAngular', 'ngFileUpload', 'ngImgCrop',
                                'uiGmapgoogle-maps', 'angularResizable',
                                'ui.router.grant', 'googlechart', '720kb.socialshare']);
