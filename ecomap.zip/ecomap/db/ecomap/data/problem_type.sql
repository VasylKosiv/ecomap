insert into problem_type (id, picture, name, radius) values (1, '1.png', 'Проблеми лісів', 500);
insert into problem_type (id, picture, name, radius) values (2, '2.png', 'Сміттєзвалища', 500);
insert into problem_type (id, picture, name, radius) values (3, '3.png', 'Незаконна забудова', 500);
insert into problem_type (id, picture, name, radius) values (4, '4.png', 'Проблеми водойм', 500);
insert into problem_type (id, picture, name, radius) values (5, '5.png', 'Загрози біорізноманіттю', 500);
insert into problem_type (id, picture, name, radius) values (6, '6.png', 'Браконьєрство', 500);
insert into problem_type (id, picture, name, radius) values (7, '7.png', 'Інші проблеми', 500);
